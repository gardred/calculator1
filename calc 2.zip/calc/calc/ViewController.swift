//
//  ViewController.swift
//  calculator
//
//  Created by Сережа Присяжнюк on 11/18/19.
//  Copyright © 2019 Сережа Присяжнюк. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

 
    @IBOutlet weak var display: UILabel!
    
    var userIsIntheMiddleOfTyping = false
    
    @IBAction func touchDigit(_ sender: UIButton)
{
        let digit = sender.currentTitle!
        if userIsIntheMiddleOfTyping
    {
        let textCurrentlyInDisplay = display!.text
        display!.text = textCurrentlyInDisplay! + digit
    }
        else
        {
            display!.text = digit
            userIsIntheMiddleOfTyping = true
        }
    
}
    
    var displayValue : Double
    {
        get
        {
            return Double(display.text!)!
        }
        set
        {
            display.text = String(newValue)
        }
    }
    
    private var brain = CalculatorBrain ()
    
    @IBAction func performOpertaion(_ sender: UIButton)
    {
        if userIsIntheMiddleOfTyping
        {
            brain.setOperand(displayValue)
        userIsIntheMiddleOfTyping = false
        }
        if let mathematicalSymbol = sender.currentTitle
    {
            brain.performOperation (mathematicalSymbol)
    }
        if let result = brain.result
        {
        displayValue  = result
        }
    
}
}
